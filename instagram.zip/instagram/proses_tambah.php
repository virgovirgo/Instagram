<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location:login.php?pesan=login");
}
include "koneksi.php";
require "functions.php";

if (isset($_POST['simpan'])) {
    $gambar = upload();
    $judul = $_POST['judul'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    
    $sql = "INSERT INTO post (gambar,judul,caption,lokasi) VALUES ('$gambar','$judul','$caption','$lokasi')";
    $query = mysqli_query($koneksi, $sql);
    // var_dump($sql);
    // die;
    echo "<script>
    alert('Data berhasil ditambah!');
    document.location.href = 'index.php';
    </script>
    ";
}


?>