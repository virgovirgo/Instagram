<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location:login.php?pesan=login");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="card col-sm-6 mx-auto mt-5">
        <h5 class="card-header">Form Tambah</h5>
        <div class="card-body">
            <form action="proses_tambah.php" method="post" enctype="multipart/form-data" autocomplete="off">
                <div class="form-group">
                    <label for="">Gambar</label>
                    <input type="file" class="form-control" name="gambar" id="" required><br>
                </div>
                <div class="form-group">
                    <label for="">Judul</label>
                    <input type="text" class="form-control" name="judul" id="" required><br>
                </div>
                <div class="form-group">
                    <label for="">Caption</label>
                    <textarea  type="text" name="caption" class = "form-control" id="" required></textarea><br>
                </div>
                <div class="form-group">
                    <label for="">Lokasi</label>
                    <input type="text" name="lokasi" class="form-control" id="" required><br>
                </div>
                <button type="submit" class="btn btn-primary" name="simpan">POST</button>
</form>
</div>
</div>
</html>